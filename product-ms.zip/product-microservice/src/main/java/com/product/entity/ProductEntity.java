package com.product.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProductEntity 
{
	@Id
	@Column(name="PRODUCT_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 Integer productId;
	
	@Column(name="NAME")
	 String name;
	
	@Column(name="DESCRIPTION")
	 String description;
	
	@Column(name="CATEGORY")
	 String category;
	
	@Column(name="BRAND")
	 String brand;
	
	@Column(name="PRICE")
	 Double price;
	
	@Column(name="DISCOUNT")
	 Double discount; 
	
	
	public ProductEntity()
	{
		super();
	}
	

	public ProductEntity(Integer productId, String name, String description, String category, String brand,
			Double price, Double discount) {
		super();
		this.productId = productId;
		this.name = name;
		this.description = description;
		this.category = category;
		this.brand = brand;
		this.price = price;
		this.discount = discount;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}


	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	

}
