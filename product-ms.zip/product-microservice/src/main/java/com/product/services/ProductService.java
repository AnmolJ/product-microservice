package com.product.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.product.dto.ProductDTO;
import com.product.entity.ProductEntity;
import com.product.repository.ProductRepository;

public class ProductService {
@Autowired
ProductRepository productRepository;

 public ProductDTO getProduct( int pk)
 {
	 ProductDTO productDTO = new ProductDTO();
	 Optional<ProductEntity> productEntityOpt = productRepository.findById(pk);
	 ProductEntity productEntity = productEntityOpt.get();
	 productDTO = ProductDTO.valueOf(productEntity);
	 
	 
	 return productDTO;
	 
 }

}
