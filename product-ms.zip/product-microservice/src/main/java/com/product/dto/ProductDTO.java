package com.product.dto;

import com.product.entity.ProductEntity;

public class ProductDTO {
	 Integer productId;
     String name;
	 String description;
	 String category;
	 String brand;
	 Double price;
	 Double discount;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	 
	 public static ProductDTO valueOf(ProductEntity productEntity)
	 {
		 ProductDTO productDTO = new ProductDTO();
		 productDTO.productId = productEntity.getProductId();
		 productDTO.name = productEntity.getName();
		 productDTO.description = productEntity.getDescription();
		 productDTO.category = productEntity.getCategory();
		 productDTO.brand = productEntity.getBrand();
		 productDTO.price = productEntity.getPrice();
		 productDTO.discount = productEntity.getDiscount();
		 return productDTO;
		 
	 }
	 public static ProductEntity createEntity(ProductDTO productDTO)
	 {
		 ProductEntity productEntity = new ProductEntity();
		 productEntity.setProductId(productDTO.getProductId());
		 productEntity.setName(productDTO.getName());
		 productEntity.setDescription(productDTO.getDescription());
		 productEntity.setDiscount(productDTO.getDiscount());
		 productEntity.setCategory(productDTO.getCategory());
		 productEntity.setPrice(productDTO.getPrice());
		 productEntity.setDiscount(productDTO.getDiscount());
		 return productEntity;
		 
		 
		 
		 
	 }
	
	
}
