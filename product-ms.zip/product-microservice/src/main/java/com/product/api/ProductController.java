package com.product.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.product.dto.ProductDTO;
import com.product.services.ProductService;

@RestController
public class ProductController {
@Autowired

ProductService productService;

@GetMapping(value = "/products")
public ProductDTO getCustomer(@RequestParam("productId")int productId)
{
	ProductDTO productDTO = null;
	productDTO = productService.getProduct(productId);
	return productDTO;
}

}
